package com.gamingroom;

/**
 * Tests the GameService singleton.
 *
 * @author coce@snhu.edu
 */
public class SingletonTester {

    /**
     * Confirms that repeated calls to getInstance() return the same object.
     */
    public void testSingleton() {
        System.out.println("\nAbout to test the singleton...");

        GameService firstReference = GameService.getInstance();
        GameService secondReference = GameService.getInstance();

        System.out.println("Both references point to the same service: "
                + (firstReference == secondReference));

        for (int i = 0; i < firstReference.getGameCount(); i++) {
            System.out.println(firstReference.getGame(i));
        }
    }
}

package com.gamingroom;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * A singleton service for the game engine.
 *
 * @author coce@snhu.edu
 */
public class GameService {

    /**
     * A list of the active games.
     */
    private static final List<Game> games = new ArrayList<Game>();

    /**
     * Holds the next game identifier.
     */
    private static long nextGameId = 1;

    /**
     * The single GameService object shared by the entire application.
     *
     * The singleton pattern limits this class to one object in memory. The
     * private constructor prevents other classes from using new GameService(),
     * while getInstance() provides one shared access point. In this application,
     * that keeps all game records and identifiers managed by the same service.
     */
    private static final GameService instance = new GameService();

    /**
     * Private constructor used to prevent other classes from creating additional
     * GameService objects.
     */
    private GameService() {
    }

    /**
     * Returns the one shared GameService instance.
     *
     * @return the singleton GameService instance
     */
    public static GameService getInstance() {
        return instance;
    }

    /**
     * Constructs a new game instance when the requested name is not already in
     * use.
     *
     * The iterator pattern provides a standard way to move through every Game
     * object in the collection without exposing how the list stores its data.
     * Here, the iterator checks each active game so duplicate names are not added.
     *
     * @param name the unique name of the game
     * @return the new game, or the existing game when the name is already in use
     */
    public Game addGame(String name) {
        Game game = null;

        Iterator<Game> iterator = games.iterator();
        while (iterator.hasNext()) {
            Game currentGame = iterator.next();

            if (currentGame.getName().equals(name)) {
                game = currentGame;
                break;
            }
        }

        if (game == null) {
            game = new Game(nextGameId++, name);
            games.add(game);
        }

        return game;
    }

    /**
     * Returns the game instance at the specified index.
     * <p>
     * Scope is package/local for testing purposes.
     * </p>
     *
     * @param index index position in the list to return
     * @return requested game instance
     */
    Game getGame(int index) {
        return games.get(index);
    }

    /**
     * Returns the game instance with the specified identifier.
     *
     * The iterator checks each game in sequence until it finds the matching ID.
     * This keeps the search logic independent of the collection implementation.
     *
     * @param id unique identifier of the game to search for
     * @return requested game instance, or null when no match exists
     */
    public Game getGame(long id) {
        Game game = null;

        Iterator<Game> iterator = games.iterator();
        while (iterator.hasNext()) {
            Game currentGame = iterator.next();

            if (currentGame.getId() == id) {
                game = currentGame;
                break;
            }
        }

        return game;
    }

    /**
     * Returns the game instance with the specified name.
     *
     * The iterator visits each active game and stops when it finds the matching
     * unique name.
     *
     * @param name unique name of the game to search for
     * @return requested game instance, or null when no match exists
     */
    public Game getGame(String name) {
        Game game = null;

        Iterator<Game> iterator = games.iterator();
        while (iterator.hasNext()) {
            Game currentGame = iterator.next();

            if (currentGame.getName().equals(name)) {
                game = currentGame;
                break;
            }
        }

        return game;
    }

    /**
     * Returns the number of games currently active.
     *
     * @return the number of games currently active
     */
    public int getGameCount() {
        return games.size();
    }
}

package com.gamingroom;

/**
 * Base class for objects that share an identifier and name.
 *
 * Game, Team, and Player inherit these common fields and methods so the same
 * code does not have to be repeated in every class.
 *
 * @author coce@snhu.edu
 */
public class Entity {

    private final long id;
    private final String name;

    /**
     * Creates an entity with a unique identifier and name.
     *
     * @param id the entity's unique identifier
     * @param name the entity's name
     */
    public Entity(long id, String name) {
        this.id = id;
        this.name = name;
    }

    /**
     * @return the unique identifier
     */
    public long getId() {
        return id;
    }

    /**
     * @return the entity name
     */
    public String getName() {
        return name;
    }

    @Override
    public String toString() {
        return "Entity [id=" + id + ", name=" + name + "]";
    }
}

package com.gamingroom;

/**
 * Stores information about a player.
 *
 * Player inherits the shared id and name fields from Entity.
 *
 * @author coce@snhu.edu
 */
public class Player extends Entity {

    /**
     * Creates a player with a unique identifier and name.
     *
     * @param id the player's unique identifier
     * @param name the player's unique name
     */
    public Player(long id, String name) {
        super(id, name);
    }

    @Override
    public String toString() {
        return "Player [id=" + getId() + ", name=" + getName() + "]";
    }
}

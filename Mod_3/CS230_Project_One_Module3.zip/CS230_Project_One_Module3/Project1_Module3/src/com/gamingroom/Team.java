package com.gamingroom;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Stores a team and the players assigned to it.
 *
 * Team inherits the shared id and name fields from Entity.
 *
 * @author coce@snhu.edu
 */
public class Team extends Entity {

    private static long nextPlayerId = 1;
    private final List<Player> players = new ArrayList<Player>();

    /**
     * Creates a team with a unique identifier and name.
     *
     * @param id the team's unique identifier
     * @param name the team's unique name
     */
    public Team(long id, String name) {
        super(id, name);
    }

    /**
     * Adds a player only when the requested name is not already on this team.
     * The iterator pattern checks the collection without exposing how it is
     * stored.
     *
     * @param name the requested player name
     * @return the existing player or the newly created player
     */
    public Player addPlayer(String name) {
        Player player = null;

        Iterator<Player> iterator = players.iterator();
        while (iterator.hasNext()) {
            Player currentPlayer = iterator.next();

            if (currentPlayer.getName().equals(name)) {
                player = currentPlayer;
                break;
            }
        }

        if (player == null) {
            player = new Player(nextPlayerId++, name);
            players.add(player);
        }

        return player;
    }

    /**
     * Returns a player at the requested list position.
     *
     * @param index the player's list position
     * @return the player at the requested position
     */
    public Player getPlayer(int index) {
        return players.get(index);
    }

    /**
     * @return the number of players assigned to the team
     */
    public int getPlayerCount() {
        return players.size();
    }

    @Override
    public String toString() {
        return "Team [id=" + getId() + ", name=" + getName() + "]";
    }
}

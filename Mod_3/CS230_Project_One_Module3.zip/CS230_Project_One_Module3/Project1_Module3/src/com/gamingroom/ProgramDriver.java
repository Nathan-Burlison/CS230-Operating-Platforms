package com.gamingroom;

/**
 * Application start-up program.
 *
 * @author coce@snhu.edu
 */
public class ProgramDriver {

    /**
     * Runs basic tests for the singleton, inheritance, unique names, teams, and
     * players.
     *
     * @param args command-line arguments
     */
    public static void main(String[] args) {

        GameService service = GameService.getInstance();

        System.out.println("About to test game data...");

        Game gameOne = service.addGame("Game #1");
        Game gameTwo = service.addGame("Game #2");
        Game duplicateGame = service.addGame("Game #1");

        System.out.println(gameOne);
        System.out.println(gameTwo);
        System.out.println("Duplicate game returned existing object: "
                + (gameOne == duplicateGame));

        Team teamOne = gameOne.addTeam("Team #1");
        Team teamTwo = gameOne.addTeam("Team #2");
        Team duplicateTeam = gameOne.addTeam("Team #1");

        System.out.println("\nAbout to test team data...");
        System.out.println(teamOne);
        System.out.println(teamTwo);
        System.out.println("Duplicate team returned existing object: "
                + (teamOne == duplicateTeam));

        Player playerOne = teamOne.addPlayer("Player #1");
        Player playerTwo = teamOne.addPlayer("Player #2");
        Player duplicatePlayer = teamOne.addPlayer("Player #1");

        System.out.println("\nAbout to test player data...");
        System.out.println(playerOne);
        System.out.println(playerTwo);
        System.out.println("Duplicate player returned existing object: "
                + (playerOne == duplicatePlayer));

        System.out.println("\nLookup by ID: " + service.getGame(gameTwo.getId()));
        System.out.println("Lookup by name: " + service.getGame("Game #1"));
        System.out.println("Game count: " + service.getGameCount());
        System.out.println("Team count in Game #1: " + gameOne.getTeamCount());
        System.out.println("Player count in Team #1: " + teamOne.getPlayerCount());

        SingletonTester tester = new SingletonTester();
        tester.testSingleton();
    }
}

CS 230 Project One - Draw It or Lose It

This Eclipse project includes:
- Entity base class with shared id and name fields
- Game, Team, and Player inheritance
- Singleton GameService implementation
- Iterator-based duplicate checks and game searches
- Unique game, team, and player identifiers
- ProgramDriver tests for games, teams, players, and the singleton

Import into Eclipse:
1. Extract the ZIP file.
2. In Eclipse, select File > Import > General > Existing Projects into Workspace.
3. Select the extracted module2_completed folder.
4. Run ProgramDriver.java as a Java Application.

package com.gamingroom;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Stores a game and the teams taking part in it.
 *
 * Game inherits the shared id and name fields from Entity.
 *
 * @author coce@snhu.edu
 */
public class Game extends Entity {

    private static long nextTeamId = 1;
    private final List<Team> teams = new ArrayList<Team>();

    /**
     * Creates a game with a unique identifier and name.
     *
     * @param id the game's unique identifier
     * @param name the game's unique name
     */
    public Game(long id, String name) {
        super(id, name);
    }

    /**
     * Adds a team only when the requested name is not already in this game.
     * The iterator pattern checks every current team before a new one is made.
     *
     * @param name the requested team name
     * @return the existing team or the newly created team
     */
    public Team addTeam(String name) {
        Team team = null;

        Iterator<Team> iterator = teams.iterator();
        while (iterator.hasNext()) {
            Team currentTeam = iterator.next();

            if (currentTeam.getName().equals(name)) {
                team = currentTeam;
                break;
            }
        }

        if (team == null) {
            team = new Team(nextTeamId++, name);
            teams.add(team);
        }

        return team;
    }

    /**
     * Returns a team at the requested list position.
     *
     * @param index the team's list position
     * @return the team at the requested position
     */
    public Team getTeam(int index) {
        return teams.get(index);
    }

    /**
     * @return the number of teams assigned to the game
     */
    public int getTeamCount() {
        return teams.size();
    }

    @Override
    public String toString() {
        return "Game [id=" + getId() + ", name=" + getName() + "]";
    }
}

package com.gamingroom;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * A singleton service that manages all game objects.
 *
 * @author coce@snhu.edu
 */
public class GameService {

    private static final List<Game> games = new ArrayList<Game>();
    private static long nextGameId = 1;

    /**
     * The singleton pattern allows only one GameService object to exist. The
     * private constructor blocks other classes from creating separate services,
     * and getInstance() gives the application one shared access point. This keeps
     * game names and identifiers managed in one place.
     */
    private static final GameService instance = new GameService();

    /**
     * Prevents outside classes from creating another GameService object.
     */
    private GameService() {
    }

    /**
     * @return the one shared GameService instance
     */
    public static GameService getInstance() {
        return instance;
    }

    /**
     * Adds a game only when its name is not already in use. The iterator pattern
     * checks each game in the collection before creating a new object.
     *
     * @param name the requested game name
     * @return the existing game or the newly created game
     */
    public Game addGame(String name) {
        Game game = null;

        Iterator<Game> iterator = games.iterator();
        while (iterator.hasNext()) {
            Game currentGame = iterator.next();

            if (currentGame.getName().equals(name)) {
                game = currentGame;
                break;
            }
        }

        if (game == null) {
            game = new Game(nextGameId++, name);
            games.add(game);
        }

        return game;
    }

    /**
     * Returns a game at the requested list position.
     *
     * @param index the game's list position
     * @return the game at the requested position
     */
    Game getGame(int index) {
        return games.get(index);
    }

    /**
     * Searches for a game by its unique identifier using an iterator.
     *
     * @param id the requested game identifier
     * @return the matching game or null when no game is found
     */
    public Game getGame(long id) {
        Game game = null;

        Iterator<Game> iterator = games.iterator();
        while (iterator.hasNext()) {
            Game currentGame = iterator.next();

            if (currentGame.getId() == id) {
                game = currentGame;
                break;
            }
        }

        return game;
    }

    /**
     * Searches for a game by its unique name using an iterator.
     *
     * @param name the requested game name
     * @return the matching game or null when no game is found
     */
    public Game getGame(String name) {
        Game game = null;

        Iterator<Game> iterator = games.iterator();
        while (iterator.hasNext()) {
            Game currentGame = iterator.next();

            if (currentGame.getName().equals(name)) {
                game = currentGame;
                break;
            }
        }

        return game;
    }

    /**
     * @return the number of active games
     */
    public int getGameCount() {
        return games.size();
    }
}

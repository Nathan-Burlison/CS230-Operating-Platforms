package com.gamingroom.gameauth.auth;

import io.dropwizard.auth.Authorizer;

/**
 * Grants access when the authenticated user has the role required by a resource.
 */
public class GameAuthorizer implements Authorizer<GameUser> {

    @Override
    public boolean authorize(GameUser user, String role) {
        return user != null
                && user.getRoles() != null
                && user.getRoles().contains(role);
    }
}

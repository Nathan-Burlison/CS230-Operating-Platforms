package com.gamingroom;

/**
 * A class to test a singleton's behavior.
 *
 * @author coce@snhu.edu
 */
public class SingletonTester {

    /**
     * Verifies that repeated calls to getInstance() return the same service and
     * that the service still contains the games added by ProgramDriver.
     */
    public void testSingleton() {

        System.out.println("\nAbout to test the singleton...");

        GameService service = GameService.getInstance();
        GameService secondReference = GameService.getInstance();

        System.out.println("Both references point to the same service: "
                + (service == secondReference));

        for (int i = 0; i < service.getGameCount(); i++) {
            System.out.println(service.getGame(i));
        }
    }
}

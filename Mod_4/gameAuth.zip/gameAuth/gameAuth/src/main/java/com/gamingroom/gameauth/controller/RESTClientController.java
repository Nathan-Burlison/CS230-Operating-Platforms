package com.gamingroom.gameauth.controller;

import java.util.ArrayList;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.gamingroom.gameauth.representations.GameUserInfo;

/**
 * Demonstrates client-side calls to the protected game-user REST API.
 */
@Produces(MediaType.TEXT_PLAIN)
@Path("/client/")
public class RESTClientController {
    private final Client client;

    public RESTClientController(Client client) {
        this.client = client;
    }

    @GET
    @Path("/gameusers/")
    public String getGameUsers() {
        // The prototype uses the local server address supplied by the assignment.
        WebTarget webTarget = client.target("http://localhost:8080/gameusers");
        Invocation.Builder invocationBuilder = webTarget.request(MediaType.APPLICATION_JSON);
        Response response = invocationBuilder.get();
        @SuppressWarnings("rawtypes")
        ArrayList gameUsers = response.readEntity(ArrayList.class);
        return gameUsers.toString();
    }

    @GET
    @Path("/gameusers/{id}")
    public String getGameUserById(@PathParam("id") int id) {
        WebTarget webTarget = client.target("http://localhost:8080/gameusers/" + id);
        Invocation.Builder invocationBuilder = webTarget.request(MediaType.APPLICATION_JSON);
        Response response = invocationBuilder.get();
        GameUserInfo gameUserInfo = response.readEntity(GameUserInfo.class);
        return gameUserInfo.toString();
    }
}

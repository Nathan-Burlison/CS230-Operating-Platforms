package com.gamingroom.gameauth.auth;

import io.dropwizard.auth.AuthenticationException;
import io.dropwizard.auth.Authenticator;
import io.dropwizard.auth.basic.BasicCredentials;

import java.util.Map;
import java.util.Optional;
import java.util.Set;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.ImmutableSet;

/**
 * Validates the username and password supplied through HTTP Basic Authentication.
 */
public class GameAuthenticator implements Authenticator<BasicCredentials, GameUser> {

    private static final Map<String, Set<String>> VALID_USERS = ImmutableMap.of(
        "guest", ImmutableSet.of(),
        "user", ImmutableSet.of("USER"),
        "player", ImmutableSet.of("PLAYER"),
        "admin", ImmutableSet.of("ADMIN", "USER")
    );

    @Override
    public Optional<GameUser> authenticate(BasicCredentials credentials)
            throws AuthenticationException {
        String username = credentials.getUsername();

        if (VALID_USERS.containsKey(username)
                && "password".equals(credentials.getPassword())) {
            // Authentication succeeded, so return a principal containing the user's roles.
            return Optional.of(new GameUser(username, VALID_USERS.get(username)));
        }

        // An empty Optional tells Dropwizard that the credentials were invalid.
        return Optional.empty();
    }
}

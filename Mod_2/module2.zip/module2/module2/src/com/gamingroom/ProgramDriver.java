package com.gamingroom;

/**
 * Application start-up program.
 *
 * @author coce@snhu.edu
 */
public class ProgramDriver {

    /**
     * The one-and-only main() method.
     *
     * @param args command-line arguments
     */
    public static void main(String[] args) {

        // Obtain the one shared GameService instance instead of creating a new one.
        GameService service = GameService.getInstance();

        System.out.println("\nAbout to test initializing game data...");

        // Initialize with some game data.
        Game game1 = service.addGame("Game #1");
        System.out.println(game1);

        Game game2 = service.addGame("Game #2");
        System.out.println(game2);

        // Verify that a duplicate name returns the existing Game object.
        Game duplicateGame = service.addGame("Game #1");
        System.out.println("Duplicate returned existing game: " + (game1 == duplicateGame));

        // Demonstrate the iterator-based lookup methods.
        System.out.println("Lookup by ID: " + service.getGame(game2.getId()));
        System.out.println("Lookup by name: " + service.getGame("Game #1"));

        // Use another class to prove there is only one GameService instance.
        SingletonTester tester = new SingletonTester();
        tester.testSingleton();
    }
}
